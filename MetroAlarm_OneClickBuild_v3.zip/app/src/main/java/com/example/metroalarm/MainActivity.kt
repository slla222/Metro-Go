package com.example.metroalarm

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.navigation.compose.rememberNavController
import com.example.metroalarm.service.RouteHolder
import com.example.metroalarm.ui.navigation.AppNavHost
import com.example.metroalarm.ui.theme.MetroTheme
import com.google.accompanist.permissions.*
import com.example.metroalarm.data.Station

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContent {
      var dark by remember { mutableStateOf(false) }
      MetroTheme(dark = dark) {
        val nav = rememberNavController()
        val perms = rememberMultiplePermissionsState(
          listOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.POST_NOTIFICATIONS)
        )
        LaunchedEffect(Unit) { perms.launchMultiplePermissionRequest() }
        Scaffold(topBar = { TopAppBar(title = { Text(getString(R.string.app_name)) }) }) { padding ->
          AppNavHost(nav = nav, padding = padding, onToggleTheme = { dark = !dark })
        }
      }
    }
  }

  fun startTracking(routeStations: List<Station>) {
    RouteHolder.route = routeStations
    val intent = android.content.Intent(this, com.example.metroalarm.service.TrackingService::class.java)
    startForegroundService(intent)
  }
}
