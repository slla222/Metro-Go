package com.example.metroalarm.billing

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.*
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

class BillingClientManager(context: Context) : PurchasesUpdatedListener {
  private val client = BillingClient.newBuilder(context)
    .setListener(this)
    .enablePendingPurchases()
    .build()

  var isPro = false; private set

  suspend fun connect(): Boolean = suspendCancellableCoroutine { cont ->
    client.startConnection(object: BillingClientStateListener {
      override fun onBillingSetupFinished(result: BillingResult) { cont.resume(result.responseCode==BillingClient.BillingResponseCode.OK) }
      override fun onBillingServiceDisconnected() { if (!cont.isCompleted) cont.resume(false) }
    })
  }

  fun launchPurchase(activity: Activity) {
    // TODO: Query product details from Play Console (product id: pro_upgrade)
    // This throws at runtime by design in the demo.
    val params = BillingFlowParams.newBuilder()
      .setProductDetailsParamsList(listOf(
        BillingFlowParams.ProductDetailsParams.newBuilder()
          .setProductDetails(returnFake())
          .build()
      )).build()
    client.launchBillingFlow(activity, params)
  }

  private fun returnFake(): ProductDetails { throw NotImplementedError("Query ProductDetails via queryProductDetailsAsync") }

  override fun onPurchasesUpdated(result: BillingResult, purchases: MutableList<Purchase>?) {
    if (result.responseCode == BillingClient.BillingResponseCode.OK) {
      isPro = purchases?.any { it.products.contains("pro_upgrade") } == true
    }
  }
}
