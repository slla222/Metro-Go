package com.example.metroalarm.data

import android.content.Context
import kotlinx.serialization.json.Json
import kotlinx.serialization.decodeFromString

class MetroDataSource(private val context: Context) {
  private val json by lazy { Json { ignoreUnknownKeys = true; prettyPrint = false } }

  fun load(): MetroData =
    runCatching { context.assets.open("stations_moscow_full.json") }.getOrElse {
      context.assets.open("stations_moscow_min.json")
    }.use { stream ->
      val txt = stream.bufferedReader().readText()
      json.decodeFromString<MetroData>(txt)
    }
}
