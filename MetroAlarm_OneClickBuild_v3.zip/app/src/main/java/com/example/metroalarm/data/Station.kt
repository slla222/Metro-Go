package com.example.metroalarm.data
import kotlinx.serialization.Serializable

@Serializable
data class Station(
  val id: String,
  val nameRu: String,
  val nameEn: String,
  val lat: Double,
  val lon: Double,
  val lineId: String,
  val neighbors: List<Edge>
)

@Serializable
data class Edge(
  val toStationId: String,
  val travelSeconds: Int
)

@Serializable
data class MetroData(val stations: List<Station>)
