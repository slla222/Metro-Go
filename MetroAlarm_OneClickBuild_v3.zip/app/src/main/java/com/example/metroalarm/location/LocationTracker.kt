package com.example.metroalarm.location

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import com.google.android.gms.location.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged

class LocationTracker(context: Context) {
  private val client = LocationServices.getFusedLocationProviderClient(context)

  @SuppressLint("MissingPermission")
  fun locationFlow() = callbackFlow<Location> {
    val req = LocationRequest.Builder(Priority.PRIORITY_BALANCED_POWER_ACCURACY, 3000L)
      .setMinUpdateIntervalMillis(1500L)
      .setWaitForAccurateLocation(false)
      .build()
    val cb = object: LocationCallback() {
      override fun onLocationResult(result: LocationResult) {
        result.lastLocation?.let { trySend(it) }
      }
    }
    client.requestLocationUpdates(req, cb, android.os.Looper.getMainLooper())
    awaitClose { client.removeLocationUpdates(cb) }
  }.distinctUntilChanged { a, b -> a.latitude==b.latitude && a.longitude==b.longitude }
}
