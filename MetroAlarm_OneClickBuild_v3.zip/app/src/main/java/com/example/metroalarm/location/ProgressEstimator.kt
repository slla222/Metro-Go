package com.example.metroalarm.location

import android.location.Location
import com.example.metroalarm.data.Station
import kotlin.math.hypot
import kotlin.math.cos
import kotlin.math.PI

class ProgressEstimator(private val route: List<Station>) {
  private var legIndex = 0
  private var legStartMillis = System.currentTimeMillis()
  private val avgSpeedMps = 14.0 // ~50 km/h with stops

  fun updateWithLocation(loc: Location): Pair<Int, Float> { // index, 0..1
    if (legIndex >= route.lastIndex) return route.lastIndex to 1f
    val a = route[legIndex]
    val b = route[legIndex+1]
    val dMeters = distance(a, b)
    val elapsed = ((System.currentTimeMillis()-legStartMillis)/1000.0)
    val tBySpeed = if (avgSpeedMps > 0) dMeters/avgSpeedMps else 1.0
    val gpsFactor = gpsProgress(loc, a, b)
    val est = (elapsed/tBySpeed*0.5 + gpsFactor*0.5).toFloat().coerceIn(0f, 1f)
    if (est >= 0.98f) { legIndex++; legStartMillis = System.currentTimeMillis() }
    return legIndex to est
  }

  private fun distance(a: Station, b: Station): Double {
    val dx = (a.lon-b.lon) * 111320.0 * cos(((a.lat+b.lat)/2) * PI / 180.0)
    val dy = (a.lat-b.lat) * 110540.0
    return hypot(dx, dy)
  }

  private fun gpsProgress(loc: Location, a: Station, b: Station): Double {
    val total = distance(a,b)
    if (total < 1.0) return 1.0
    val da = hypot((loc.longitude-a.lon)* 97400.0, (loc.latitude-a.lat)*110540.0)
    val db = hypot((loc.longitude-b.lon)* 97400.0, (loc.latitude-b.lat)*110540.0)
    val along = (total - db).coerceIn(0.0, total)
    return (along/total)
  }
}
