package com.example.metroalarm.routing

import com.example.metroalarm.data.*
import java.util.PriorityQueue

class Router(private val data: MetroData) {
  data class Path(val stations: List<Station>, val totalSeconds: Int)

  private val stationById = data.stations.associateBy { it.id }

  fun findRoute(fromId: String, toId: String): Path? {
    val dist = mutableMapOf<String, Int>().withDefault { Int.MAX_VALUE }
    val prev = mutableMapOf<String, String?>()
    val pq = PriorityQueue(compareBy<Pair<String, Int>> { it.second })

    dist[fromId] = 0
    pq.add(fromId to 0)

    while (pq.isNotEmpty()) {
      val (u, du) = pq.poll()
      if (u == toId) break
      if (du != dist.getValue(u)) continue
      val uStation = stationById[u] ?: continue
      for (e in uStation.neighbors) {
        val alt = du + e.travelSeconds
        if (alt < dist.getValue(e.toStationId)) {
          dist[e.toStationId] = alt
          prev[e.toStationId] = u
          pq.add(e.toStationId to alt)
        }
      }
    }

    if (!prev.containsKey(toId) && fromId != toId) return null

    val pathIds = mutableListOf<String>()
    var cur: String? = toId
    pathIds.add(cur!!)
    while (cur != fromId) {
      cur = prev[cur]
      if (cur == null) break
      pathIds.add(cur)
    }
    pathIds.reverse()

    val stations = pathIds.mapNotNull { stationById[it] }
    return Path(stations, dist.getValue(toId))
  }
}
