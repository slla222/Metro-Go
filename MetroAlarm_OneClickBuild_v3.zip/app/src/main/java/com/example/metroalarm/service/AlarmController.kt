package com.example.metroalarm.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.net.Uri
import androidx.core.app.NotificationCompat
import com.example.metroalarm.R
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem

object AlarmController {
  private var proUri: Uri? = null

  fun setCustomSound(uri: Uri?) { proUri = uri }

  fun trigger(ctx: Context) {
    val mgr = ctx.getSystemService(NotificationManager::class.java)
    val ch = NotificationChannel("alarm", "Wake before station", NotificationManager.IMPORTANCE_HIGH)
    mgr.createNotificationChannel(ch)
    val n = NotificationCompat.Builder(ctx, "alarm")
      .setSmallIcon(R.drawable.ic_alarm)
      .setContentTitle(ctx.getString(R.string.alarm_title))
      .setContentText(ctx.getString(R.string.alarm_text))
      .setPriority(NotificationCompat.PRIORITY_MAX)
      .setFullScreenIntent(null, true)
      .build()
    mgr.notify(777, n)

    val player = ExoPlayer.Builder(ctx).build()
    val uri = proUri ?: Uri.parse("asset:///default_alarm.wav")
    val item = MediaItem.fromUri(uri)
    player.setMediaItem(item)
    player.setAudioAttributes(
      com.google.android.exoplayer2.audio.AudioAttributes.Builder()
        .setContentType(com.google.android.exoplayer2.C.AUDIO_CONTENT_TYPE_MUSIC)
        .setUsage(com.google.android.exoplayer2.C.USAGE_ALARM).build(), true)
    player.prepare(); player.play()
  }
}
