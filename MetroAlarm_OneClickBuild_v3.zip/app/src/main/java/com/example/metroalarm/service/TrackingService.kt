package com.example.metroalarm.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.metroalarm.R
import com.example.metroalarm.data.Station
import com.example.metroalarm.location.LocationTracker
import com.example.metroalarm.location.ProgressEstimator
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest

class TrackingService : Service() {
  private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
  private lateinit var tracker: LocationTracker
  private lateinit var estimator: ProgressEstimator
  private lateinit var route: List<Station>
  private var targetIndex: Int = 0

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onCreate() {
    super.onCreate()
    tracker = LocationTracker(this)
    createChannel()
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    @Suppress("DEPRECATION") val notif = buildNotification("Поезд отслеживается…")
    startForeground(42, notif)

    route = ServiceArgs.from(intent)
    estimator = ProgressEstimator(route)
    targetIndex = (route.size - 2).coerceAtLeast(0) // 1 before destination

    scope.launch {
      tracker.locationFlow().collectLatest { loc ->
        val (idx, progress) = estimator.updateWithLocation(loc)
        updateNotification("Станция: ${route[idx].nameRu} (${(progress*100).toInt()}%)")
        if (idx >= targetIndex) {
          AlarmController.trigger(this@TrackingService)
          stopSelf()
        }
      }
    }

    return START_STICKY
  }

  override fun onDestroy() { scope.cancel(); super.onDestroy() }

  private fun createChannel() {
    val mgr = getSystemService(NotificationManager::class.java)
    val ch = NotificationChannel("track", "Metro Tracking", NotificationManager.IMPORTANCE_LOW)
    mgr.createNotificationChannel(ch)
  }

  private fun buildNotification(text: String): Notification =
    NotificationCompat.Builder(this, "track")
      .setSmallIcon(R.drawable.ic_train)
      .setContentTitle(getString(R.string.app_name))
      .setContentText(text)
      .setOngoing(true)
      .build()

  private fun updateNotification(text: String) {
    val mgr = getSystemService(NotificationManager::class.java)
    mgr.notify(42, buildNotification(text))
  }
}

object ServiceArgs {
  fun from(intent: Intent?): List<Station> = RouteHolder.route
}

object RouteHolder { lateinit var route: List<Station> }
