package com.example.metroalarm.ui.navigation

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.metroalarm.ui.screens.MapScreen
import com.example.metroalarm.ui.screens.RoutePlannerScreen
import com.example.metroalarm.ui.screens.SettingsScreen
import com.example.metroalarm.ui.screens.AboutScreen

@Composable
fun AppNavHost(nav: NavHostController, padding: PaddingValues, onToggleTheme: ()->Unit) {
  NavHost(navController = nav, startDestination = "map") {
    composable("map") { MapScreen() }
    composable("plan") { RoutePlannerScreen(onStart = { nav.navigate("map") }) }
    composable("settings") { SettingsScreen(onToggleTheme) }
    composable("about") { AboutScreen() }
  }
}
