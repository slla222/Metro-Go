package com.example.metroalarm.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun AboutScreen() {
  Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Text("О приложении", style = MaterialTheme.typography.titleLarge)
    Text("Metro Alarm — тестовый проект. Карта: “Moscow metro map sb.svg” (Wikimedia Commons, CC BY-SA 4.0). Изменения возможны. Источник и авторы указаны на странице файла.")
    Text("Данные станций: Wikidata/Wikipedia (онлайн выгрузка).")
  }
}
