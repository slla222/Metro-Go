package com.example.metroalarm.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.TransformableState
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.decode.SvgDecoder

@Composable
fun MapScreen() {
  val ctx = LocalContext.current
  var scale by remember { mutableStateOf(1f) }
  var offsetX by remember { mutableStateOf(0f) }
  var offsetY by remember { mutableStateOf(0f) }

  val transformState: TransformableState = rememberTransformableState { zoomChange, panChange, _ ->
    scale = (scale * zoomChange).coerceIn(0.5f, 5f)
    offsetX += panChange.x
    offsetY += panChange.y
  }

  Column(Modifier.fillMaxSize()) {
    Text(
      text = "Карта Московского метро",
      style = MaterialTheme.typography.titleMedium,
      modifier = Modifier.padding(12.dp)
    )
    Box(
      modifier = Modifier
        .fillMaxSize()
        .clipToBounds()
        .background(MaterialTheme.colorScheme.background)
        .transformable(transformState)
    ) {
      AsyncImage(
        model = ImageRequest.Builder(ctx)
          .data("file:///android_asset/metro_map.svg")
          .decoderFactory(SvgDecoder.Factory())
          .build(),
        contentDescription = null,
        modifier = Modifier
          .align(Alignment.TopStart)
          .graphicsLayer {
            scaleX = scale
            scaleY = scale
            translationX = offsetX
            translationY = offsetY
          }
      )
      // TODO: Overlay route polyline + train dot using stations_map_pixels.json
    }
  }
}
