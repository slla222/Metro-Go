package com.example.metroalarm.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.metroalarm.data.MetroDataSource
import com.example.metroalarm.routing.Router
import com.example.metroalarm.MainActivity

@Composable
fun RoutePlannerScreen(onStart: ()->Unit) {
  val ctx = LocalContext.current
  val data = remember { MetroDataSource(ctx).load() }
  var from by remember { mutableStateOf(data.stations.first().id) }
  var to by remember { mutableStateOf(data.stations.last().id) }
  val router = remember { Router(data) }
  var route by remember { mutableStateOf<Router.Path?>(null) }

  Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    Text("Маршрут")
    ExposedDropdown("Откуда", data.stations.map { it.id }, from) { from = it }
    ExposedDropdown("Куда", data.stations.map { it.id }, to) { to = it }
    Button(onClick = { route = router.findRoute(from, to) }) { Text("Построить") }
    route?.let { p ->
      Text("Время: ${p.totalSeconds/60} мин")
      Button(onClick = {
        (ctx as MainActivity).startTracking(p.stations)
        onStart()
      }) { Text("Старт и буди за 1 станцию") }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ExposedDropdown(label: String, items: List<String>, selected: String, onPick: (String)->Unit) {
  var expanded by remember { mutableStateOf(false) }
  ExposedDropdownMenuBox(expanded, onExpandedChange = { expanded = it }) {
    OutlinedTextField(
      modifier = Modifier.menuAnchor(),
      value = selected, onValueChange = {}, readOnly = true,
      label = { Text(label) }
    )
    ExposedDropdownMenu(expanded, onDismissRequest = { expanded = false }) {
      items.forEach { id -> DropdownMenuItem(text={ Text(id) }, onClick={ onPick(id); expanded=false }) }
    }
  }
}
