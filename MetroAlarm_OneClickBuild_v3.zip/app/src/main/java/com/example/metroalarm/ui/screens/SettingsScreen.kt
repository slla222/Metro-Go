package com.example.metroalarm.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.metroalarm.service.AlarmController

@Composable
fun SettingsScreen(onToggleTheme: ()->Unit) {
  var isPro by remember { mutableStateOf(false) } // wire to Billing in real app
  val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
    if (isPro) AlarmController.setCustomSound(uri)
  }

  Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    Text("Настройки")
    Button(onClick = onToggleTheme) { Text("Сменить тему") }
    Row { Checkbox(checked = isPro, onCheckedChange = { isPro = it }); Text("Я Pro (демо)") }
    Button(onClick = { if (isPro) pickAudio.launch(arrayOf("audio/*")) }) { Text("Выбрать звук будильника (Pro)") }
  }
}
