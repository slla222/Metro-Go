package com.example.metroalarm.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable

private val Dark = darkColorScheme()
private val Light = lightColorScheme()

@Composable
fun MetroTheme(dark: Boolean, content: @Composable ()->Unit) {
  MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}
